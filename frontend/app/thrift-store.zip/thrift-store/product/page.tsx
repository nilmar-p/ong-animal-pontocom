export default function Product() {
  return (
    <div className="container product-container">

      <h6 className="fw-bold">Peça de roupa xxx clara</h6>

      <div className="row g-2 align-items-stretch">

        <div
          className="col-3 d-flex flex-column justify-content-between"
          style={{ height: "210px" }}
        >
          <div className="thumbnail flex-fill mb-1"></div>
          <div className="thumbnail flex-fill mb-1"></div>
          <div className="thumbnail flex-fill"></div>
        </div>

        <div className="col-9">
          <div className="main-image h-100"></div>
        </div>

      </div>

      <div className="d-flex align-items-center justify-content-between mt-3">

        <div>
          <p className="price mb-0">R$ 00,00</p>
          <small className="text-muted">
            2x de R$ 6,50 sem juros no cartão
          </small>
        </div>

        <button className="btn btn-buy px-3">
          Comprar
        </button>

      </div>

      <p className="mt-3 small">
        Quisque lectus consequat lorem, eu lobortis augue efficitur vel.
        Maecenas egestas libero at auctor vehicula. Nunc ac augue,
        iaculis laoreet leo. Mauris dictum magna at nisl iaculis.
      </p>

      <hr />

      <div className="row g-3 mt-3">

        <div className="col-6">
          <div className="p-2 border rounded text-center small bg-light">
            <div
              className="bg-secondary-subtle rounded mb-2"
              style={{ height: "70px" }}
            ></div>
            Auctor justo amet
            <br />
            <span className="fw-bold">R$ 00,00</span>
          </div>
        </div>

        <div className="col-6">
          <div className="p-2 border rounded text-center small bg-light">
            <div
              className="bg-secondary-subtle rounded mb-2"
              style={{ height: "70px" }}
            ></div>
            Auctor justo amet
            <br />
            <span className="fw-bold">R$ 00,00</span>
          </div>
        </div>

        <div className="col-6">
          <div className="p-2 border rounded text-center small bg-light">
            <div
              className="bg-secondary-subtle rounded mb-2"
              style={{ height: "70px" }}
            ></div>
            Auctor justo amet
            <br />
            <span className="fw-bold">R$ 00,00</span>
          </div>
        </div>

        <div className="col-6">
          <div className="p-2 border rounded text-center small bg-light">
            <div
              className="bg-secondary-subtle rounded mb-2"
              style={{ height: "70px" }}
            ></div>
            Auctor justo amet
            <br />
            <span className="fw-bold">R$ 00,00</span>
          </div>
        </div>

      </div>

    </div>
  );
}