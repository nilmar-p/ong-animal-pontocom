import Link from "next/link";

export default function ThriftStore() {
  return (
    <div className="container mt-3">

      <h6 className="fw-bold mb-3">Peças disponíveis</h6>

      <div className="row g-2">

        <div className="col-4 d-flex flex-column justify-content-between">

          <div className="item-card mb-2">
            <div className="img-placeholder"></div>
          </div>

          <div className="item-card mb-2">
            <div className="img-placeholder"></div>
          </div>

          <div className="item-card">
            <div className="img-placeholder"></div>
          </div>

        </div>

        <div className="col-8">

          <div className="item-card h-100">
            <div
              className="img-placeholder"
              style={{ height: "100%" }}
            ></div>
          </div>

        </div>

      </div>

      <hr />

      {/* Linha de produtos */}

      <div className="row mt-3 g-3">

        <div className="col-6">

          <Link href="/thrift-store/product">

            <div className="item-card">

              <div className="img-placeholder"></div>

              <div className="info">
                <h6>Auctor justo amet</h6>
                <p>R$ 00,00</p>
              </div>

            </div>

          </Link>

        </div>

        <div className="col-6">
          <div className="item-card">
            <div className="img-placeholder"></div>
            <div className="info">
              <h6>Auctor justo amet</h6>
              <p>R$ 00,00</p>
            </div>
          </div>
        </div>

        <div className="col-6">
          <div className="item-card">
            <div className="img-placeholder"></div>
            <div className="info">
              <h6>Auctor justo amet</h6>
              <p>R$ 00,00</p>
            </div>
          </div>
        </div>

        <div className="col-6">
          <div className="item-card">
            <div className="img-placeholder"></div>
            <div className="info">
              <h6>Auctor justo amet</h6>
              <p>R$ 00,00</p>
            </div>
          </div>
        </div>

        <div className="col-6">
          <div className="item-card">
            <div className="img-placeholder"></div>
            <div className="info">
              <h6>Auctor justo amet</h6>
              <p>R$ 00,00</p>
            </div>
          </div>
        </div>

        <div className="col-6">
          <div className="item-card">
            <div className="img-placeholder"></div>
            <div className="info">
              <h6>Auctor justo amet</h6>
              <p>R$ 00,00</p>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}